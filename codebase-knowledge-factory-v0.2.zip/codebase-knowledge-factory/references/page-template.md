---
title: "<descriptive title>"
audience: [developers]
status: draft
owner: Unassigned
last_verified: "<YYYY-MM-DD>"
source_revision: "<commit hash or unknown>"
source_files: []
classification: internal-review-required
---

# <Title>

## Purpose and scope
Explain why this page matters, without inventing business intent.

## Verified from source
Describe factual findings and cite repository-relative paths with lines, for example `src/App/Program.cs#L12-L24`. Ensure line ranges were actually inspected.

## Architecture or workflow
Provide an evidence-grounded explanation and Mermaid diagram if helpful.

## Inferences requiring validation
Clearly label deductions and rationale.

## Unknowns and owner questions
- Unknown — needs owner confirmation: ...

## Source references
- `path/to/file`: what it establishes

## Related pages
Link to other generated pages using relative Markdown links.
