# Document catalog

Generate pages only when supported by evidence. Suggested output paths:

- `START-HERE.md`: role-based navigation and getting started
- `foundation/CODEBASE-OVERVIEW.md`: what the repository contains and verified purpose
- `applications/APPLICATION-CATALOG.md`: executables, services, web apps, workers, libraries, entry points
- `architecture/SYSTEM-CONTEXT.md`: verified boundaries, dependencies and integrations
- `architecture/DEPENDENCY-MAP.md`: project/module references, package dependencies
- `architecture/DECISIONS-OBSERVED.md`: patterns evident in code; **not** invented ADRs
- `interfaces/API-CATALOG.md`: HTTP routes, handlers, contracts, auth annotations
- `data/DATA-ARCHITECTURE.md`: contexts, migrations, persistence, SQL artifacts
- `integrations/INTEGRATION-CATALOG.md`: outbound clients, queues, events, external dependencies
- `engineering/DEVELOPER-SETUP.md`: prerequisites, build/run/test steps verified from scripts
- `engineering/TESTING-GUIDE.md`: frameworks, test projects, execution patterns
- `engineering/CODE-CONVENTIONS.md`: demonstrated coding practices
- `delivery/CI-CD.md`: pipelines, triggers, stages, deployment configuration
- `operations/CONFIGURATION-REFERENCE.md`: safe configuration key names and purpose
- `operations/OPERATIONS-AND-RUNBOOK-GAPS.md`: observable monitoring and missing operational facts
- `domain/GLOSSARY.md`: terms evidenced in identifiers, schemas, comments or docs
- `impact/CHANGE-IMPACT-GUIDE.md`: dependent modules and likely test impact (qualified)
- `governance/SECURITY-OBSERVATIONS.md`: observed controls, not compliance claims
- `reference/SOURCE-INVENTORY.md`: scanned source boundaries and exclusions
- `reference/OPEN-QUESTIONS.md`: missing facts and designated reviewers if known
- `reference/COVERAGE-REPORT.md`: documented vs discovered components
- `reference/PUBLISH-MANIFEST.md`: reviewed publication candidates and classification

For large monorepos, split application pages per app and create catalog indexes. Never force all pages to exist if no evidence is available; record gaps instead.
