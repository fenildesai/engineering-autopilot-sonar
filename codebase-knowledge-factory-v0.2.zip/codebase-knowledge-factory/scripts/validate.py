#!/usr/bin/env python3
"""Heuristic Markdown checks. Not a substitute for manual review."""
import argparse,re,sys
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--docs',required=True);p.add_argument('--repo',required=True);a=p.parse_args()
 docs=Path(a.docs).resolve();repo=Path(a.repo).resolve()
 if not docs.is_dir() or not repo.is_dir():p.error('docs and repo must exist')
 problems=[];count=0
 for file in docs.rglob('*.md'):
  count+=1;text=file.read_text(encoding='utf-8',errors='replace')
  if not text.startswith('---\n'):problems.append(f'{file}: missing YAML frontmatter')
  if not re.search(r'(?m)^# ',text):problems.append(f'{file}: missing H1 heading')
  if not re.search(r'(?m)^## Source references',text) and file.name!='START-HERE.md':problems.append(f'{file}: missing Source references section')
  for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
   target=target.split('#',1)[0].strip()
   if not target or target.startswith(('http://','https://','mailto:','#')):continue
   if not (file.parent/target).resolve().is_file():problems.append(f'{file}: broken local link {target}')
  for pattern in [r'(?i)(?:password|api[_-]?key|client[_-]?secret)\s*[:=]\s*["\']?[^\s"\']{8,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']:
   if re.search(pattern,text):problems.append(f'{file}: possible secret (manual review required)')
 print(f'Checked {count} Markdown files; {len(problems)} issue(s).')
 for issue in problems:print('WARNING:',issue)
 return 1 if problems else 0
if __name__=='__main__':sys.exit(main())
