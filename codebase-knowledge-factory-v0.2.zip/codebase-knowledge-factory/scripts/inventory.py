#!/usr/bin/env python3
"""Bounded read-only repository inventory. Standard library only."""
import argparse, hashlib, json, os
from pathlib import Path
from datetime import datetime, timezone

EXCLUDE={'.git','.svn','node_modules','bin','obj','dist','build','coverage','.next','.venv','venv','packages','target','.idea','.vs'}
SUFFIXES={'.cs','.csproj','.sln','.slnx','.fs','.fsproj','.vbproj','.java','.kt','.gradle','.py','.js','.jsx','.ts','.tsx','.go','.rs','.sql','.json','.yaml','.yml','.xml','.toml','.props','.targets','.md','.sh','.ps1','.tf','.bicep','.cshtml','.config','.graphql','.proto'}
SECRET_PARTS=('secret','credential','password','private_key','id_rsa','.pfx','.p12','.pem','.key','.env')
MAX_FILES=30000
MAX_HASH_BYTES=2_000_000

def main():
 p=argparse.ArgumentParser(); p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 root=Path(a.root).resolve();out=Path(a.out).resolve()
 if not root.is_dir(): p.error('Root must be an existing directory')
 files=[];excluded=0;truncated=False
 for base,dirs,names in os.walk(root):
  dirs[:]=sorted(d for d in dirs if d not in EXCLUDE and not d.startswith('.git'))
  for name in sorted(names):
   path=Path(base)/name; rel=path.relative_to(root).as_posix(); lower=name.lower()
   if any(part in lower for part in SECRET_PARTS) or path.suffix.lower() not in SUFFIXES or path.is_symlink(): excluded+=1;continue
   if len(files)>=MAX_FILES:truncated=True;break
   try:
    size=path.stat().st_size
    digest=None
    if size<=MAX_HASH_BYTES:
     digest=hashlib.sha256(path.read_bytes()).hexdigest()
    files.append({'path':rel,'extension':path.suffix.lower(),'bytes':size,'sha256':digest})
   except (OSError,PermissionError): excluded+=1
  if truncated:break
 payload={'schema_version':1,'generated_at':datetime.now(timezone.utc).isoformat(),'root':str(root),'files':files,'excluded_file_count':excluded,'truncated':truncated,'limitations':['Candidate files only; no semantic architecture analysis','Ignored files and large-file hashes excluded','Not a secret scanner']}
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
 print(f'Inventoried {len(files)} files; excluded {excluded}; truncated={truncated}; output={out}')
if __name__=='__main__':main()
