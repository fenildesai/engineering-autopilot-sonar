#!/usr/bin/env python3
"""Offline Markdown-to-HTML knowledge portal. No third-party dependencies."""
import argparse, html, json, re, shutil
from pathlib import Path
from urllib.parse import quote

STYLE = r'''*{box-sizing:border-box}body{margin:0;font:15px/1.65 Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif;background:#f6f8fc;color:#17233b}body.dark{background:#0c1424;color:#e5edf9}a{color:#2463c9;text-decoration:none}a:hover{text-decoration:underline}.sidebar{position:fixed;inset:0 auto 0 0;width:285px;background:#111c31;color:#d9e5fa;padding:25px 16px;overflow:auto;z-index:3}.brand{font-weight:800;font-size:20px;letter-spacing:-.5px;padding:0 10px 18px}.brand small{display:block;font-size:11px;color:#93a7c8;font-weight:500;letter-spacing:1px;text-transform:uppercase}.search{width:100%;background:#23324b;border:1px solid #3b4b65;color:white;border-radius:10px;padding:12px;margin:0 0 18px}.navtitle{font-size:10px;letter-spacing:1.7px;text-transform:uppercase;color:#8fa5c7;padding:14px 11px 6px}.nav a{display:block;color:#bacbe5;padding:9px 12px;border-radius:9px;font-size:13px;margin:2px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nav a:hover,.nav a.active{background:#2b4064;color:white;text-decoration:none}.main{margin-left:285px;padding:36px 52px 100px;max-width:1480px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:25px}.crumb{font-size:12px;color:#7183a1}.actions{display:flex;gap:8px}.btn{background:#fff;border:1px solid #dce4f0;border-radius:9px;padding:8px 12px;color:#263b5e;cursor:pointer}.article{background:#fff;border:1px solid #e2e9f2;border-radius:17px;padding:42px 52px;box-shadow:0 15px 45px #1e3c6c0a;max-width:1050px}.article h1{font-size:34px;line-height:1.2;letter-spacing:-1px;margin:0 0 18px}.article h2{margin-top:36px;border-bottom:1px solid #e8edf5;padding-bottom:8px}.article h3{margin-top:25px}.article p,.article li{color:#475670}.article code{background:#eef3fa;padding:2px 5px;border-radius:4px}.article pre{background:#101c30;color:#dceaff;padding:20px;border-radius:11px;overflow:auto}.article pre code{background:none;color:inherit;padding:0}.article table{border-collapse:collapse;width:100%;display:block;overflow-x:auto}.article th,.article td{padding:10px 14px;border:1px solid #dce4ef;text-align:left}.article th{background:#eef3fa}.article blockquote{border-left:4px solid #5d8de3;padding:5px 20px;background:#f1f6ff;margin:20px 0}.article img{max-width:100%}.eyebrow{color:#5275a8;font-weight:700;font-size:11px;letter-spacing:1.6px;text-transform:uppercase}.empty{color:#a5b3ca;padding:12px;font-size:13px}.toc{font-size:12px;color:#7688a5}.footer{font-size:12px;color:#8c9ab0;margin-top:30px}.mobile{display:none}body.dark .article{background:#17233a;border-color:#30415e}body.dark .article p,body.dark .article li{color:#b6c6e1}body.dark .btn{background:#263653;color:#fff;border-color:#405271}body.dark .article h2{border-color:#334460}body.dark .article th{background:#263653}body.dark .article td,body.dark .article th{border-color:#41516a}body.dark .article code{background:#2b3b56}body.dark .article blockquote{background:#223653}@media(max-width:850px){.sidebar{transform:translateX(-100%);transition:transform .2s}.sidebar.open{transform:none}.main{margin:0;padding:20px 16px}.article{padding:26px 20px}.mobile{display:inline-block}}'''
JS = r'''const pages=__PAGES__;const nav=document.getElementById('nav'),article=document.getElementById('article'),crumb=document.getElementById('crumb'),q=document.getElementById('search');let current='';function show(id){const p=pages.find(x=>x.id===id)||pages[0];if(!p)return;current=p.id;article.innerHTML=p.html;crumb.textContent=p.section+' / '+p.title;document.title=p.title+' · Codebase Knowledge Hub';history.replaceState(null,'','#'+encodeURIComponent(p.id));renderNav(q.value);document.querySelector('.sidebar').classList.remove('open');window.scrollTo(0,0)}function renderNav(filter=''){nav.innerHTML='';let last='';const s=filter.toLowerCase();let count=0;for(const p of pages){if(s&&!((p.title+' '+p.section+' '+p.text).toLowerCase().includes(s)))continue;if(last!==p.section){const h=document.createElement('div');h.className='navtitle';h.textContent=p.section;nav.appendChild(h);last=p.section}const a=document.createElement('a');a.href='#'+encodeURIComponent(p.id);a.textContent=p.title;a.className=p.id===current?'active':'';a.onclick=e=>{e.preventDefault();show(p.id)};nav.appendChild(a);count++}if(!count){const e=document.createElement('div');e.className='empty';e.textContent='No matching documents';nav.appendChild(e)}}q.addEventListener('input',()=>renderNav(q.value));document.getElementById('theme').onclick=()=>document.body.classList.toggle('dark');document.getElementById('menu').onclick=()=>document.querySelector('.sidebar').classList.toggle('open');window.addEventListener('hashchange',()=>show(decodeURIComponent(location.hash.slice(1))));show(decodeURIComponent(location.hash.slice(1))||pages[0]?.id);'''

def inline(s, page, known):
    s=html.escape(s)
    s=re.sub(r'`([^`]+)`',lambda m:'<code>'+m[1]+'</code>',s)
    def link(m):
        label,url=m.groups(); target=url.split('#')[0]; frag=('#'+url.split('#',1)[1]) if '#' in url else ''
        if target.lower().endswith('.md'):
            dest=(page.parent/target).resolve()
            if dest in known: return '<a href="#'+html.escape(quote(known[dest]+frag),quote=True)+'">'+label+'</a>'
        if url.startswith(('https://','http://','mailto:','#')):return '<a href="'+html.escape(url,quote=True)+'"'+(' target="_blank" rel="noopener noreferrer"' if url.startswith('http') else '')+'>'+label+'</a>'
        return label
    s=re.sub(r'\[([^\]]+)\]\(([^\s)]+)\)',link,s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',s)
    return s

def render(md,page,known):
    lines=md.splitlines();out=[];i=0;fence=False;code=[];listtype=None;table=[]
    def close_list():
        nonlocal listtype
        if listtype:out.append('</'+listtype+'>');listtype=None
    def close_table():
        nonlocal table
        if table:
            out.append('<table>')
            for j,cells in enumerate(table):out.append('<tr>'+''.join('<'+('th' if j==0 else 'td')+'>'+inline(x.strip(),page,known)+'</'+('th' if j==0 else 'td')+'>' for x in cells)+'</tr>')
            out.append('</table>');table=[]
    while i<len(lines):
        line=lines[i];strip=line.strip()
        if strip.startswith('```'):
            close_list();close_table()
            if not fence:fence=True;code=[]
            else:out.append('<pre><code>'+html.escape('\n'.join(code))+'</code></pre>');fence=False
            i+=1;continue
        if fence:code.append(line);i+=1;continue
        if strip.startswith('|') and strip.endswith('|'):
            cells=strip.strip('|').split('|')
            if all(re.fullmatch(r'\s*:?-{3,}:?\s*',x) for x in cells):i+=1;continue
            close_list();table.append(cells);i+=1;continue
        close_table()
        if not strip:close_list();i+=1;continue
        h=re.match(r'^(#{1,6})\s+(.+)',strip)
        if h:
            close_list();n=len(h[1]);label=h[2];slug=re.sub('[^a-z0-9-]','',re.sub(r'\s+','-',label.lower()))
            out.append(f'<h{n} id="{slug}">'+inline(label,page,known)+f'</h{n}>');i+=1;continue
        m=re.match(r'^\s*[-*+]\s+(.+)',line)
        num=re.match(r'^\s*\d+\.\s+(.+)',line)
        if m or num:
            t='ul' if m else 'ol'
            if listtype!=t:close_list();out.append('<'+t+'>');listtype=t
            out.append('<li>'+inline((m or num)[1],page,known)+'</li>');i+=1;continue
        close_list()
        if strip.startswith('>'):out.append('<blockquote>'+inline(strip.lstrip('> '),page,known)+'</blockquote>')
        elif strip in ('---','***'):out.append('<hr>')
        else:out.append('<p>'+inline(strip,page,known)+'</p>')
        i+=1
    close_list();close_table()
    if fence:out.append('<pre><code>'+html.escape('\n'.join(code))+'</code></pre>')
    return '\n'.join(out)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--docs',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.docs).resolve();out=Path(a.out).resolve()
    if not root.is_dir():p.error('docs directory not found')
    if out==root or root in out.parents:p.error('output must be outside the Markdown source directory')
    docs=sorted(root.rglob('*.md'));known={x.resolve():x.relative_to(root).with_suffix('').as_posix() for x in docs};pages=[]
    for file in docs:
        raw=file.read_text(encoding='utf-8-sig',errors='replace')
        if raw.startswith('---\n') and '\n---\n' in raw[4:]:raw=raw.split('\n---\n',1)[1]
        heading=re.search(r'^#\s+(.+)$',raw,re.M);title=heading[1].strip() if heading else file.stem.replace('-',' ').title()
        rel=file.relative_to(root);section=rel.parts[0].replace('-',' ').title() if len(rel.parts)>1 else 'Getting started'
        pages.append(dict(id=known[file.resolve()],title=title,section=section,html=render(raw,file,known),text=re.sub(r'[#*`|>\[\]()]',' ',raw)[:20000]))
    if not pages:p.error('no Markdown files found')
    pages.sort(key=lambda x:(0 if x['id'].lower() in ('start-here','index','readme') else 1,x['id']))
    out.mkdir(parents=True,exist_ok=True)
    payload=json.dumps(pages,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026').replace('\u2028','\\u2028')
    js=JS.replace('__PAGES__',payload)
    page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Codebase Knowledge Hub</title><style>{STYLE}</style></head><body><aside class="sidebar"><div class="brand">◈ Knowledge Hub<small>Codebase Intelligence</small></div><input class="search" id="search" placeholder="Search all documents…" aria-label="Search documentation"><nav id="nav" class="nav"></nav></aside><main class="main"><header class="top"><div><button class="btn mobile" id="menu" aria-label="Open navigation">☰ Menu</button><div class="crumb" id="crumb"></div></div><div class="actions"><button class="btn" id="theme" aria-label="Toggle dark mode">◐ Theme</button></div></header><div class="article" id="article"></div><div class="footer">Generated from Markdown · Verify all content before publication</div></main><script>{js}</script></body></html>'''
    (out/'index.html').write_text(page,encoding='utf-8')
    print(f'Generated {out / "index.html"} with {len(pages)} Markdown pages')
if __name__=='__main__':main()
