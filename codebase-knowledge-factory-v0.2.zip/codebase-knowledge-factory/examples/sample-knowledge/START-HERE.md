# Welcome to the Knowledge Hub

This is a **sample portal**. Replace these pages with documentation generated from your repository.

## Explore the documentation

- [Architecture overview](architecture/ARCHITECTURE.md)
- [Developer setup](DEVELOPER-SETUP.md)

## What this contains

| Area | Purpose |
| --- | --- |
| Architecture | Explain components and dependencies |
| Onboarding | Help engineers get started |

> All project-specific facts must be verified against actual source files.
