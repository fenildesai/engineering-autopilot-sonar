# Developer Setup

## Prerequisites

- Check the repository README.
- Inspect the build configuration.

## Next steps

Return to [Welcome](START-HERE.md).
