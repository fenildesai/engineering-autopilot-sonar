# Architecture Overview

## Components

This example contains no real application facts.

```mermaid
flowchart LR
  A[Web app] --> B[Service]
  B --> C[(Database)]
```

## Evidence

- Verify dependencies from source files before publishing.
