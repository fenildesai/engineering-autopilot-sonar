# Codebase Knowledge Factory

A portable GitHub Copilot agent skill for source-grounded software documentation. Works with Copilot CLI or compatible agent skill runners. No MCP or external connectors required.

## Install
Copy this entire folder (including `scripts/` and `references/`) to `.github/skills/codebase-knowledge-factory/` in a repository, or to your user-level Copilot skills directory if supported by your client. Confirm skill discovery in your Copilot client.

## Try it
Ask Copilot: **"Use codebase-knowledge-factory in Discover mode. Inventory this repo and propose the Markdown documentation plan. Don't modify source code."**

Or run inventory manually:

```bash
python3 .github/skills/codebase-knowledge-factory/scripts/inventory.py --root . --out ./knowledge-output/inventory.json
```

After Copilot generates documents in `knowledge-output/knowledge`:

```bash
python3 .github/skills/codebase-knowledge-factory/scripts/validate.py --docs ./knowledge-output/knowledge --repo .
```

The scripts use Python's standard library. Keep generated documentation in a separate folder or workspace if you don't want to commit it. Review all generated material before publishing.

## Boundaries
The inventory detects file types and candidate project/CI configuration files; it does not itself parse every language or prove architecture. Copilot should inspect specific relevant files and cite evidence. The validator checks local links, source path references and some secret-like patterns, but does not guarantee security or correctness. Jira, Confluence, and SharePoint integrations are optional future extensions and not included.

## Contributing upstream
For `github/awesome-copilot`, first read the repository's current contribution instructions, naming conventions, and skill schema. Submit a focused pull request with this skill, sample output from a safe synthetic repository, and tests. Upstream acceptance is not guaranteed.

## Generate the HTML knowledge portal

After generating Markdown in `knowledge-output/knowledge`, run:

```bash
python3 .github/skills/codebase-knowledge-factory/scripts/build_portal.py --docs ./knowledge-output/knowledge --out ./knowledge-output/portal
```

Open `knowledge-output/portal/index.html` in a browser. It provides a responsive left navigation panel, client-side search, breadcrumbs, theme switching, and linked pages. The entire site is a single self-contained HTML file, with no CDN, server, or additional dependencies. Markdown remains authoritative. The renderer supports common headings, lists, tables, code fences, links and blockquotes, but is not a complete CommonMark implementation; Mermaid fences display as source code.
