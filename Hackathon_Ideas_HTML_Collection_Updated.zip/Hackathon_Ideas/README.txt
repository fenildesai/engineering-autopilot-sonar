Open index.html in any browser. All pages work offline. These are concept pitch pages, not connected Power Apps or running agents.
