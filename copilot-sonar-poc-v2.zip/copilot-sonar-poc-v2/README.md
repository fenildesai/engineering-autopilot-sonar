# Copilot Sonar PoC v2

Two alternatives using the same repository skill catalogue:

1. `copilot-app-poc` — GitHub Copilot App manages isolated working-tree sessions.
2. `local-cli-poc` — PowerShell creates worktrees and starts Copilot CLI workers.

Both use the same flattened `.github/skills/<skill-name>/SKILL.md` structure.

Recommended order:
- prove skill discovery;
- one SAFE known Sonar issue;
- two parallel known issues;
- targeted validation;
- only then add Sonar API discovery/triage;
- automate push/PR last.
