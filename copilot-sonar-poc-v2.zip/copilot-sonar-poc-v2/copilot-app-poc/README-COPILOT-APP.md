# GitHub Copilot App — Sonar Remediation PoC

## Repository files to add
Copy the supplied `repo-files/.github` directory into the root of your monorepo.

The skill layout is intentionally flat:
`.github/skills/<skill-name>/SKILL.md`

## First validation: confirm discovery
Open the monorepo as a Project in GitHub Copilot App.
Use Customize > Skills (or ask the agent to list/identify available repository skills) and confirm:
- sonar-discovery
- sonar-triage
- sonar-remediation
- targeted-validation
- change-review
- azure-devops-pr-prep

If the app detects `.github/github-app.yml`, review and accept it before use.

## PoC A — one finding
Start a new session for the project and choose **New working tree**.

Prompt:
Use the /sonar-remediation skill.
Fix only this pre-approved SAFE Sonar finding:
Issue: SONAR-001
Rule: <rule>
File: <path>
Line: <line>
Message: <message>

Use /targeted-validation after the change.
Do not push, merge, or create a PR.
Stop if the change is not clearly behaviour-preserving.

Review the diff and validation evidence.

## PoC B — parallel sessions
Create 2–3 separate sessions, each using **New working tree**.
Give each session a different pre-approved SAFE finding.

Example:
Session 1 -> SONAR-001
Session 2 -> SONAR-002
Session 3 -> SONAR-003

The Copilot App owns the isolated workspaces/worktrees and branches. Do not manually create worktrees for this App PoC.

## Large-monorepo rule
Do not start by building the full monorepo. Give each task a targeted build/test command or let the agent identify the smallest relevant project and ask before running expensive repository-wide validation.

## PoC C — discovery/triage
Only after remediation works:
1. Use /sonar-discovery to retrieve/summarize findings using your approved Sonar access mechanism.
2. Use /sonar-triage to shortlist SAFE findings.
3. Start one working-tree session per approved finding.
4. Use /sonar-remediation.
5. Use /targeted-validation.
6. Use /change-review.
7. Use /azure-devops-pr-prep to draft PR metadata.

Do not assume a single App automation can dynamically fan out arbitrary Sonar results into multiple sessions until that exact orchestration behavior is proven in your tenant/client.
