---
name: sonar-remediation
description: Fix one pre-approved low-risk SonarQube finding with the smallest behaviour-preserving change. Use only after a finding has been classified SAFE.
---
# Sonar remediation
1. Work on exactly one supplied finding.
2. Inspect the target file and only enough surrounding code to understand it.
3. Make the smallest behaviour-preserving change.
4. Never suppress/disable an analyzer rule just to clear the finding.
5. Do not alter public contracts, business logic, auth, persistence schemas, dependencies, pipelines, or Sonar configuration.
6. Do not broaden scope into nearby cleanup.
7. Run the supplied targeted validation.
8. If safety is uncertain, make no change and report BLOCKED.
9. Summarize files changed and why.
