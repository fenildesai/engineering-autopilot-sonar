---
name: sonar-triage
description: Classify SonarQube findings for autonomous-remediation suitability. Use after findings have been discovered and before code changes.
---
# Sonar triage
Classify each finding as SAFE, REVIEW_REQUIRED, or EXCLUDED.

SAFE is deliberately narrow for the PoC: deterministic, local, behaviour-preserving cleanup with no public-contract or runtime-behaviour change.

Always EXCLUDE or require review for security hotspots, authentication/authorization, cryptography, secrets, persistence/schema changes, public APIs, dependency upgrades, concurrency, configuration, generated code, and unclear business logic.

Explain the classification briefly. Do not edit code.
