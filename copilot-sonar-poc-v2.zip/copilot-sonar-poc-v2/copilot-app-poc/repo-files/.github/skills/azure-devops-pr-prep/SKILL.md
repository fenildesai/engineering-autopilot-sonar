---
name: azure-devops-pr-prep
description: Prepare a concise Azure DevOps pull-request title and description for an approved automated remediation. This skill does not push, merge, or create the PR unless explicitly authorized.
---
# Azure DevOps PR preparation
Produce:
- PR title
- Sonar issue/rule
- problem
- minimal change
- validation performed
- risk statement
- reviewer notes

Never claim a PR was created if it was not.
