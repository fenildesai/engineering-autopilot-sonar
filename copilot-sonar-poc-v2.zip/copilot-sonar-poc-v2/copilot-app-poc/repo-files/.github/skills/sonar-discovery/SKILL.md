---
name: sonar-discovery
description: Discover and summarize SonarQube findings for a specified project or component. Use when asked to retrieve, inspect, or shortlist Sonar findings. Do not modify source code.
---
# Sonar discovery
1. Retrieve only the requested project/component findings using the approved Sonar access method.
2. Return issue key, rule, severity, component/file, line, message and status.
3. Do not edit code.
4. Do not expose tokens or credentials.
5. If connectivity/authentication is unavailable, report BLOCKED rather than guessing.
