---
name: targeted-validation
description: Validate an AI-generated code change using the smallest relevant build and test scope for the affected component.
---
# Targeted validation
1. Inspect the diff first.
2. Reject unrelated changes.
3. Run the configured project/component build.
4. Run the smallest relevant test suite.
5. Report commands, exit results, and failures.
6. Never hide or bypass failing tests.
