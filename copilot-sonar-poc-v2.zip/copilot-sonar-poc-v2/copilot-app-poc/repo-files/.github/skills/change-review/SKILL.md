---
name: change-review
description: Review an AI-generated remediation before it is proposed for a pull request, focusing on scope, behavior, safety, and validation evidence.
---
# Change review
Check:
- the change maps to the supplied issue;
- no unrelated files changed;
- behaviour is preserved;
- no analyzer suppression was introduced;
- validation evidence exists;
- security/business logic/contracts were not unintentionally changed.

Return APPROVE_FOR_PR or REJECT with concise reasons.
