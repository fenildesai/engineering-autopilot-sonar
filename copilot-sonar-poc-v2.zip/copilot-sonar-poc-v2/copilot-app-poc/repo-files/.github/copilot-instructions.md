# Engineering agent instructions

This repository is a large enterprise monorepo.

- Prefer targeted navigation, builds and tests over whole-repository operations.
- Treat `.github/skills/` as the reusable capability catalogue.
- For Sonar remediation, use the discovery -> triage -> remediation -> targeted-validation -> change-review sequence.
- Only remediate findings explicitly classified SAFE.
- Never expose credentials, tokens or secrets.
- Do not push, merge, or create a pull request unless the user explicitly asks.
- Keep changes minimal and scoped to the task.
- If a requested action is unsafe or ambiguous, stop and explain.
