# Local Copilot CLI — Sonar Remediation PoC

## Prerequisites
- Windows PowerShell
- Git
- .NET SDK required by your repo
- GitHub Copilot CLI installed and authenticated
- Your monorepo already cloned
- The supplied `.github` repository files copied into the monorepo

Confirm skill discovery in an interactive Copilot CLI session with `/skills list`.

## Run one task first
Edit:
- `config/poc.config.json`
- `tasks/tasks.sample.json`

Keep `maxParallel` = 1.

Run:
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\Invoke-Poc.ps1 -RepoPath "C:\src\YOUR-MONOREPO"
```

## Then test parallelism
Add 2–3 independent SAFE findings to `tasks.sample.json` and set:
```json
"maxParallel": 2
```

The local orchestrator:
1. fetches the base branch;
2. creates one Git worktree/branch per task;
3. starts independent `copilot -p` processes;
4. each worker invokes the repository remediation/validation skills;
5. captures logs;
6. leaves the worktrees for human review;
7. does not commit or push.

## Large monorepo
Start with full worktrees and 1 worker. Measure disk, checkout, CPU/RAM and targeted build time before increasing concurrency. Add sparse checkout only after proving which directories/shared projects are required.

## Next stage
After both App and CLI PoCs are reliable, add:
Sonar API -> allowlist/triage -> task generation -> workers -> validation -> review -> Azure DevOps PR creation.
