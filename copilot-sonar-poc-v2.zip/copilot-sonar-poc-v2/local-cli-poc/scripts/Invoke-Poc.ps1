param(
 [Parameter(Mandatory=$true)][string]$RepoPath,
 [string]$ConfigPath="$PSScriptRoot/../config/poc.config.json",
 [string]$TasksPath="$PSScriptRoot/../tasks/tasks.sample.json"
)
$ErrorActionPreference="Stop"
$config=Get-Content $ConfigPath -Raw|ConvertFrom-Json
$tasks=@(Get-Content $TasksPath -Raw|ConvertFrom-Json)
New-Item -ItemType Directory -Force $config.worktreeRoot|Out-Null
$logDir=Join-Path (Split-Path $PSScriptRoot -Parent) "logs"
New-Item -ItemType Directory -Force $logDir|Out-Null

Push-Location $RepoPath
try {
  git fetch $config.remote
  if($LASTEXITCODE-ne 0){throw "git fetch failed"}
} finally {Pop-Location}

# Start conservatively. This simple orchestrator processes tasks in batches up to maxParallel.
for($i=0;$i -lt $tasks.Count;$i += [int]$config.maxParallel){
  $batch=$tasks[$i..([Math]::Min($i+[int]$config.maxParallel-1,$tasks.Count-1))]
  $jobs=@()
  foreach($task in $batch){
    $safe=($task.id -replace '[^A-Za-z0-9._-]','-').ToLowerInvariant()
    $branch="ai/poc/$safe"
    $wt=Join-Path $config.worktreeRoot $safe
    if(Test-Path $wt){throw "Worktree already exists: $wt"}
    Push-Location $RepoPath
    try {
      git worktree add -b $branch $wt "$($config.remote)/$($config.baseBranch)"
      if($LASTEXITCODE-ne 0){throw "worktree creation failed for $($task.id)"}
    } finally {Pop-Location}

    $jobs += Start-Job -FilePath "$PSScriptRoot/Invoke-CopilotWorker.ps1" -ArgumentList @(
      $wt,
      ($task|ConvertTo-Json -Compress),
      ($config|ConvertTo-Json -Depth 10 -Compress),
      (Join-Path $logDir "$($task.id).log")
    )
  }
  $jobs|Wait-Job|Out-Null
  foreach($j in $jobs){Receive-Job $j;Remove-Job $j}
}
Write-Host "PoC finished. Inspect each worktree. Nothing was committed or pushed."
