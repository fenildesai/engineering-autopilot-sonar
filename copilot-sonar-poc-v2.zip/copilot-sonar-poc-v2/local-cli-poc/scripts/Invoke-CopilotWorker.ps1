param(
  [Parameter(Mandatory=$true)][string]$WorktreePath,
  [Parameter(Mandatory=$true)][string]$TaskJson,
  [Parameter(Mandatory=$true)][string]$ConfigJson,
  [Parameter(Mandatory=$true)][string]$LogPath
)
$ErrorActionPreference="Stop"
$task=$TaskJson|ConvertFrom-Json
$config=$ConfigJson|ConvertFrom-Json

$prompt=@"
Use the /sonar-remediation skill.
Fix only this pre-approved SAFE Sonar finding:
Issue: $($task.id)
Rule: $($task.rule)
File: $($task.file)
Line: $($task.line)
Message: $($task.message)

Then use the /targeted-validation skill.
Build command: $($config.buildCommand)
Test command: $($config.testCommand)

Do not commit, push, merge, change branches, or create a PR.
If the change is not clearly safe and behaviour-preserving, make no change and report BLOCKED.
Finish with exactly POC_STATUS=SUCCESS, POC_STATUS=BLOCKED, or POC_STATUS=FAILED.
"@

Push-Location $WorktreePath
try {
  $out=& copilot -p $prompt -s --no-ask-user `
    --allow-tool="write" `
    --allow-tool="shell(dotnet:*)" `
    --allow-tool="shell(git status)" `
    --allow-tool="shell(git diff)" `
    --deny-tool="shell(git push)" `
    --deny-tool="shell(git commit)" `
    --deny-tool="shell(git reset)" `
    --deny-tool="shell(git clean)" 2>&1 | Out-String
  $out|Set-Content $LogPath -Encoding UTF8
  $status=if($out-match "POC_STATUS=SUCCESS"){"SUCCESS"}elseif($out-match "POC_STATUS=BLOCKED"){"BLOCKED"}else{"FAILED"}
  [pscustomobject]@{TaskId=$task.id;Status=$status;Worktree=$WorktreePath;Log=$LogPath}
} finally { Pop-Location }
